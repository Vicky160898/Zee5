
export const PAYMENT_AMOUNT = "pay/amount";
export const VALIDATE_USER = 'user/validation from accountInfo page';
export const BUY_SUBSCRIPTION = 'buy/subscription'